# Tales of Pirates CMS

Tales of Pirates was a 3D Massively Multiplayer Online Role Playing Game developed by the Chinese company MOLI.Tales of Pirates was published by IGG (I Got Games) until the game closed on February 29, 2016.

topCMS is a content management system directed at the private server development community that is trying their best to keep the game alive.
