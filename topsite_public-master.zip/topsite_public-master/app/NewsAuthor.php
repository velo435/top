<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class NewsAuthor extends Model
{
    //
    protected $connection = 'SiteInfo';
}
