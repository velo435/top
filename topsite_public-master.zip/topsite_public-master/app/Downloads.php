<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Downloads extends Model
{
    public $table = 'Downloads';
    protected $connection = 'SiteInfo';
    //
}
