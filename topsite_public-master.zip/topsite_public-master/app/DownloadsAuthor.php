<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class DownloadsAuthor extends Model
{
    //

    protected $connection = 'SiteInfo';
}
