<?php

/**
 * This file contains the values of all the jobs that are found in tales of pirates
 * corresponding to their IDs.
 */

return [
			'0'			=> 			'Newbie',
			'1'			=>			'Swordsman',
			'2'			=>			'Hunter',
			'3'			=>			'Sailor',
			'4'			=>			'Explorer',
			'5'			=>			'Herbalist',
			'6'			=>			'Artisan',
			'7'			=>			'Merchant',
			'8'			=>			'Champion',
			'9'			=>			'Crusader',
			'10'		=>			'White Knight',
			'11'		=>			'Animal Tamer',
			'12'		=>			'Sharpshooter',
			'13'		=>			'Cleric',
			'14'		=>			'Seal Master',
			'15'		=>			'Captain',
			'16'		=>			'Voyager',
			'17'		=>			'Upstart',
			'18'		=>			'Engineer'

];