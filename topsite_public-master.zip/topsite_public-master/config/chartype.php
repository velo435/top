<?php

/**
 * This contains an array having all the character types and their names
 */

return [

			'1'			=>			'Lance',
			'2'			=>			'Carsise',
			'3'			=>			'Phyllis',
			'4'			=>			'Ami'

];